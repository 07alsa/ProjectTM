namespace MemorySketch { public enum ViewMode { Mode2D, Mode3D } }
