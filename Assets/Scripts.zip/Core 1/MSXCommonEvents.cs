using UnityEngine.Events;

namespace MemorySketch.Addons
{
    [System.Serializable]
    public class StringEvent : UnityEvent<string> {}
}
